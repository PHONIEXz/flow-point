# Seabreeze Volunteer Briefing: filled template baseline

The assistant filled this worksheet from the frozen expected values. It is not an independent extraction benchmark or measured human workflow.

- title: "Seabreeze Volunteer Briefing"
- eventDate: "2027-03-20"
- startTime: "08:20"
- venue: "Seabreeze Annex"
- organizer: "Seabreeze Association"
- signatory: "Bisi Dada, Secretary"
- currency: "NGN"
- spendingLimitMinor: 1000000

| Item | Quantity | Unit price in minor units |
| --- | ---: | ---: |
| water | 20 | 15000 |
| banner | 1 | 200000 |

Known subtotal in minor units: 500000. Remaining/provisional allowance in minor units: 500000. Unknown prices: 0.

Pending questions: permit.

Invitation wording, schedule wording and full suggested checklist still require authoring and review. No time-saving claim is made.
