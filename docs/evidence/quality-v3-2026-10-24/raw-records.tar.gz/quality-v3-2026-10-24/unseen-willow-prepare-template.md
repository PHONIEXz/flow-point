# Willow Skills Exchange: filled template baseline

The assistant filled this worksheet from the frozen expected values. It is not an independent extraction benchmark or measured human workflow.

- title: "Willow Skills Exchange"
- eventDate: "2027-04-10"
- startTime: "13:10"
- venue: "Willow Room"
- organizer: "Willow Network"
- signatory: "Dan Abel, Coordinator"
- currency: "CAD"
- spendingLimitMinor: 20000

| Item | Quantity | Unit price in minor units |
| --- | ---: | ---: |
| kit | 8 | 1250 |
| room | 1 | 0 |

Known subtotal in minor units: 10000. Remaining/provisional allowance in minor units: 10000. Unknown prices: 0.

Pending questions: .

Invitation wording, schedule wording and full suggested checklist still require authoring and review. No time-saving claim is made.
