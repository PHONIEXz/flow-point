# Seabreeze Volunteer Briefing: filled template baseline

The assistant filled this worksheet from the frozen expected values. It is not an independent extraction benchmark or measured human workflow.

- title: "Seabreeze Volunteer Briefing"
- eventDate: "2027-03-20"
- startTime: "08:20"
- venue: "Seabreeze Hall"
- organizer: "Seabreeze Association"
- signatory: "Bisi Dada, Secretary"
- currency: "NGN"
- spendingLimitMinor: 1000000

| Item | Quantity | Unit price in minor units |
| --- | ---: | ---: |
| water | 15 | 15000 |
| banner | 1 | Unknown |

Known subtotal in minor units: 225000. Remaining/provisional allowance in minor units: 775000. Unknown prices: 1.

Pending questions: permit; banner price.

Invitation wording, schedule wording and full suggested checklist still require authoring and review. No time-saving claim is made.
